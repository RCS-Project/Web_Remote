/*
 * new CORS based
 * Author : Subhajit Das
 * Date : 21/02/16
 * Edit : 27/02/16
 */
var updateDaemon;
var errCount = 0;
// handles the XHR object creation
function createCORSRequest(method, url) {
    var xhr = new XMLHttpRequest();
    if ("withCredentials" in xhr) {
        // Check if the XMLHttpRequest object has a "withCredentials" property.
        // "withCredentials" only exists on XMLHTTPRequest2 objects.
        xhr.open(method, url, true);
    } else if (typeof XDomainRequest != "undefined") {
        // Otherwise, check if XDomainRequest.
        // XDomainRequest only exists in IE, and is IE's way of making CORS requests.
        xhr = new XDomainRequest();
        xhr.open(method, url);
    } else {
        // Otherwise, CORS is not supported by the browser.
        xhr = null;
        alert("Browser not supproted");
    }
    return xhr;
}
// initialy update on status and start update daemon
function init() {
    try {
        document.getElementById("keypadMask").style.display = "block";
        var xhttp = createCORSRequest('GET', "http://svc.web-remote.tk/getStatus.php");
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4) {
                if (xhttp.status == 200) {
                    try {
                        var onStatus = xhttp.responseText;
                        for (var i = 0; i < onStatus.length; i++) {
                            for (var j = i + 1; j <= i + 11; j += 10) {
                                var element = document.getElementById("k" + j);
                                // setting events
                                if (onStatus.charAt(i) === "1" || onStatus.charAt(i) === "0") {
                                    element.addEventListener("click", function () {
                                        send(this.innerHTML);
                                    });
                                }
                                // setting color
                                if (onStatus.charAt(i) === "1") {
                                    element.className = "w3-green";
                                } else if (onStatus.charAt(i) === "0") {
                                    element.className = "w3-red";
                                }
                            }
                        }
                    } catch (err) {
                    } finally {
                        document.getElementById("keypadMask").style.display = "none";
                        updateDaemon = setInterval(function () {
                            updateOnStatus();
                        }, 2000);
                    }
                } else {
                    errCount++;
                    if (errCount < 100) {
                        init();
                    } else {
                        alert("Error. Reloading page");
                        location.reload();
                    }
                }
            }
        };
        xhttp.send();
    } catch (e) {
        alert("Could not connect ot server");
    }
}
// update on status and set color accordingly
function updateOnStatus() {
    try {
        var xhttp = createCORSRequest('GET', "http://svc.web-remote.tk/getStatus.php");
        xhttp.onreadystatechange = function () {
            var errCount = 0;
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                try {
                    var onStatus = xhttp.responseText;
                    for (var i = 0; i < onStatus.length; i++) {
                        for (var j = i + 1; j <= i + 11; j += 10) {
                            var element = document.getElementById("k" + j);
                            // setting color
                            if (onStatus.charAt(i) === "1") {
                                element.className = "w3-green";
                            } else if (onStatus.charAt(i) === "0") {
                                element.className = "w3-red";
                            }
                        }
                    }
                } catch (err) {
                }
            } else {
                errCount++;
                if (errCount >= 10) {
                    alert("Server eonnntion lost");
                    location.reload();
                }
            }
        };
        xhttp.send();
    } catch (e) {
    }
}
// send the key pressed
function send(key) {
    try {
        clearInterval(updateDaemon);
        document.getElementById("keypadMask").style.display = "block";

        var xhttp = createCORSRequest('GET', "http://svc.web-remote.tk/sendRemoteData.php?data=" + key);
        xhttp.onload = function () {
            document.getElementById("out").innerHTML = xhttp.responseText;
        };
        xhttp.onloadend = function () {
            setTimeout(function () {
                document.getElementById("keypadMask").style.display = "none";
            }, 3000);

            updateDaemon = setInterval(function () {
                updateOnStatus();
            }, 2000);
        };
        xhttp.send();
    } catch (e) {
    }
}